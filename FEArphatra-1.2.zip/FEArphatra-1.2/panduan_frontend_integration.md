# Panduan Frontend
## Membangun Autentikasi dengan Firebase + Cloud API

Panduan ini dibuat khusus untuk **frontend** agar memahami:
- Mengapa kode dipisah menjadi beberapa file
- Bagaimana alur login/register bekerja
- Di mana API key seharusnya disimpan
- Praktik aman (best practice) yang wajib diketahui

Contoh yang digunakan berasal dari **hasil recode JavaScript** yang sudah kita lakukan.

---

## 1. Gambaran Arsitektur Sederhana

Frontend **TIDAK mengakses database secara langsung**.

Alurnya:

```
Browser (HTML + JS)
   │
   ├── Firebase Auth (Google Login)
   │
   └── Backend API (Cloud Function / Cloud Run)
        ├── Register
        ├── Login
        ├── Reset Password (OTP)
        └── Profile
```

> Prinsip penting: **Frontend hanya UI & request, backend yang pegang data & logika sensitif**

---

## 2. Struktur Folder yang Direkomendasikan

```
/public
 ├── index.html
 ├── js/
 │    ├── config.js   ← konfigurasi
 │    ├── ui.js       ← helper UI
 │    └── auth.js     ← logic autentikasi
```

Kenapa dipisah?
- Lebih mudah dibaca
- Mudah dirawat (maintenance)
- Tidak satu file raksasa

---

## 3. Penjelasan Setiap File

---

### 3.1 `config.js`

Berisi **konfigurasi**, bukan logika.

```js
export const API_BASE_URL = "https://api-kamu.com";

export const firebaseConfig = {
    apiKey: "FIREBASE_API_KEY",
    authDomain: "project.firebaseapp.com",
    projectId: "project-id",
};
```

📌 **Kenapa API key Firebase boleh di frontend?**
- Firebase `apiKey` **BUKAN password**
- Hanya penanda project
- Keamanan ada di **Firebase Rules**, bukan di API key

❌ Yang TIDAK BOLEH di frontend:
- Firebase Admin SDK key
- JWT secret
- SMTP password

---

### 3.2 `ui.js`

Berisi fungsi **tampilan & utilitas**, bukan auth.

```js
export function log(message, isError = false) { ... }
```

Manfaat:
- Log rapi
- Tidak mengotori file auth
- Mudah diganti (misalnya pakai toast)

---

### 3.3 `auth.js`

Ini adalah **otak utama autentikasi**.

Isi:
- Register
- Login
- Google Login
- Reset password (OTP)
- Session
- Logout

Contoh login email:

```js
const res = await fetch(`${API_BASE_URL}/login`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password })
});
```

📌 Frontend hanya kirim data → backend yang memutuskan valid atau tidak.

---

## 4. Penyimpanan Token

### Yang Dipakai Sekarang (Belajar / Prototype)

```js
localStorage.setItem('token', idToken);
```

⚠️ Kekurangan:
- Bisa dicuri jika ada XSS

### Yang Ideal (Production)

- Token disimpan di **httpOnly cookie**
- Frontend tidak bisa baca token

> Untuk pemula: **localStorage masih boleh**, asal sadar risikonya

---

## 5. Alur Login yang Mudah Dipahami

1. User isi form login
2. Frontend kirim email & password ke backend
3. Backend verifikasi
4. Backend kirim token
5. Frontend simpan token
6. Frontend minta `/profile`

Jika token invalid → logout otomatis

---

## 6. Google Login (Kenapa Dua Langkah?)

1. Firebase Auth → validasi Google
2. Dapat `idToken`
3. Kirim token ke backend
4. Backend verify token Google

> Supaya **backend tetap punya kontrol penuh**

---

## 7. Forgot Password + OTP

Kenapa OTP lewat backend?
- Email tidak boleh dikirim dari frontend
- OTP harus diverifikasi server

Frontend hanya:
- Kirim email
- Kirim OTP + password baru

---

## 8. Kesalahan Umum Pemula (Hindari Ini)

❌ Taruh Admin SDK di frontend
❌ Percaya data dari client
❌ Simpan secret di JS
❌ Pakai satu file JS besar
❌ Tidak pakai rules Firebase

---

## 9. Checklist Aman untuk Pemula

✅ Firebase Rules aktif
✅ Backend yang validasi data
✅ API key Firebase boleh publik
✅ Token tidak dipalsukan
✅ Error tidak bocorin data

---

## 10. Ringkasan Akhir

- Frontend = UI + request
- Backend = keamanan + data
- Firebase API key ≠ secret
- Pisahkan file = kode sehat

---

## Langkah Lanjutan (Opsional)

- Upgrade ke httpOnly cookie
- Tambah email verification
- Aktifkan Firebase App Check
- Audit security rules

