/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{html,js}",
    "./assets/**/*.{html,js}",
  ],
  theme: {
    extend: {
      fontFamily: {
        poppins: ['Poppins', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      colors: {
        /* Main Colors */
        vanilla: '#F1EADA',
        rice: '#F6F8ED',
        
        /* Secondary Colors */
        mahogany: '#584738',
        
        /* Optional Colors */
        mountain: '#AAA396',
        sand: '#CEC1A8',
        tobacco: '#B59E7D',
      },
      backgroundImage: {
        'background': "url('../assets/images/background-collected.png')",
      },
    },
  },
  plugins: [],
  corePlugins: {
    // Disable color utilities to keep custom CSS color variables
    backgroundColor: false,
    textColor: false,
    borderColor: false,
  },
}
