# 🚀 Quick Start: Register → Login Testing

## For the Impatient 😄

### Copy-paste these steps:

**Step 1: Go to register.html**

Open Browser Console (F12 → Console tab)

```javascript
debugRegister.clearAll()
debugRegister.testRegister('NewUser123', 'newuser123@gmail.com', 'Password123')
```

**Step 2: Wait for redirect to login.html**

Watch the console for this success message:
```
✅ Register validation PASSED
📝 User baru telah di-register, flag set ke true
Registrasi berhasil! Silahkan login
```

**Step 3: Check localStorage is correct**

```javascript
debugLogin.checkStorage()
```

Must show:
- `arphatra_user: ✅ Ada`
- `arphatra_isNewUser: true` ← **THIS IS CRITICAL**

**Step 4: Login with same credentials**

```javascript
debugLogin.testLogin('newuser123@gmail.com', 'Password123')
```

**Step 5: Check console for success**

Should show:
```
✅ Login validation PASSED - All checks passed
✅ First login after registration - NEW USER status maintained
Login berhasil!
```

---

## 🔍 If Something Goes Wrong

### Q: Register says "success" but I don't see the success message?

**A:** Check console for this:
```javascript
❌ Register validation FAILED
Alasan: {
    successIsFalse: true,    ← Backend returned success: false
    noUserId: true,          ← Backend didn't return userId
    message: "..."           ← Backend error message
}
```

**Solution:** This is a **backend issue**. Backend must return:
```json
{
    "success": true,
    "data": {
        "userId": "12345",
        "email": "user@gmail.com"
    }
}
```

---

### Q: Register works, but then login fails?

**A:** Run this to debug:

```javascript
// First check if flag survived
debugLogin.checkStorage()

// Look for arphatra_isNewUser value
// If it's 'false' or missing → flag not maintained
// If it's 'true' → should work, check login response

// Then check login response:
debugLogin.testLogin('your-email@gmail.com', 'your-password')

// Look for:
// ✅ Login validation PASSED
// ✅ First login after registration - NEW USER status maintained
```

---

### Q: Console shows login validation FAILED?

**A:** The error tells you exactly which check failed:

```javascript
❌ Login validation FAILED - Check failed:
'success === true?': false     ← success is false (wrong credentials? backend error?)
'has data object?': false      ← no data object (backend format wrong?)
'has idToken?': false          ← no idToken (backend format wrong?)
'has userId?': false           ← no userId (backend didn't return it)
'message': "User not found"    ← Backend error message
```

**Most common cause:** Backend returns wrong response format or credentials don't match what was registered.

---

### Q: Everything looks correct but I still can't login?

**A:** Get the full response:

```javascript
// Go to login page
debugLogin.fillForm('your-email@gmail.com', 'your-password')

// Open DevTools → Network tab
// Submit login form

// Check the /login request:
// - Response Status: Should be 200
// - Response Body: Should show complete API response

// Copy full response and check if:
// 1. success: true (or false?)
// 2. data.idToken: exists?
// 3. data.userId: exists?
```

If response shows `success: false`, backend didn't recognize your credentials.

---

## 🎯 Checklist Before Testing

- [ ] You're using a NEW email (not previously registered)
- [ ] Password is minimum 8 characters
- [ ] Password in register = Password in login (exactly)
- [ ] Email in register = Email in login (exactly)
- [ ] Backend API is running and responding
- [ ] Browser console is open (F12)
- [ ] You cleared localStorage with `clearAll()` first

---

## Expected Console Output Timeline

```
[Register Page]
  ↓
  debugRegister.testRegister('NewUser', 'new@gmail.com', 'Pass123')
  ↓
  Mendaftarkan user...
  📋 Register Response: { ... }
  ✅ Register validation PASSED
  📝 User baru telah di-register, flag set ke true
  Registrasi berhasil! Silahkan login
  
  [1.5 second delay...]
  
  [Auto-redirect to login.html]

[Login Page]
  ↓
  debugLogin.testLogin('new@gmail.com', 'Pass123')
  ↓
  Login via cloud...
  📋 Login Response: { ... }
  ✅ Login validation PASSED - All checks passed
  ✅ First login after registration - NEW USER status maintained
  Login berhasil!
  
  [1 second delay...]
  
  [Auto-redirect to homepage.html]

[Homepage]
  ↓
  Shows EMPTY FORM (new user state)
  ✅ SUCCESS!
```

---

## Need More Details?

See the full guide: [REGISTER_LOGIN_TESTING_GUIDE.md](REGISTER_LOGIN_TESTING_GUIDE.md)
