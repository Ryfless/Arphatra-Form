/* ============================
   PASSWORD VISIBILITY TOGGLE
============================ */
function setupPasswordToggle() {
    const toggleButtons = document.querySelectorAll('.password-toggle');

    toggleButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();

            const targetId = button.dataset.target;
            const input = document.getElementById(targetId);
            const icon = button.querySelector('img');

            if (!input || !icon) return;

            if (input.type === 'password') {
                input.type = 'text';
                icon.src = '../assets/icons/login/eye-open.svg';
            } else {
                input.type = 'password';
                icon.src = '../assets/icons/login/eye-closed.svg';
            }
        });
    });
}

/* ============================
   PASSWORD STRENGTH CHECK
   (UI ONLY - NO BACKEND)
============================ */
function setupPasswordStrengthIndicator() {
    const newPasswordInput = document.getElementById('new-password');
    const strengthText = document.getElementById('password-strength');

    if (!newPasswordInput || !strengthText) return;

    newPasswordInput.addEventListener('input', () => {
        const password = newPasswordInput.value;
        let strength = 0;

        if (password.length >= 8) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[^A-Za-z0-9]/.test(password)) strength++;

        if (!password) {
            strengthText.textContent = '';
            return;
        }

        if (strength <= 1) {
            strengthText.textContent = 'Weak password';
            strengthText.style.color = 'red';
        } else if (strength <= 3) {
            strengthText.textContent = 'Medium password';
            strengthText.style.color = 'orange';
        } else {
            strengthText.textContent = 'Strong password';
            strengthText.style.color = 'green';
        }
    });
}

/* =========================
   POPUP HANDLER
========================= */
const popupOverlay = document.getElementById('popupOverlay');
const popupMessage = document.getElementById('popupMessage');
const popupOkBtn = document.getElementById('popupOkBtn');

/**
 * Dipanggil dari HTML setelah backend sukses
 */
function showPopup(message) {
    if (!popupOverlay || !popupMessage) return;

    popupMessage.textContent = message;
    popupOverlay.classList.remove('hidden');
}

function closePopup() {
    if (!popupOverlay) return;

    popupOverlay.classList.add('hidden');
    window.location.href = 'login.html';
}

if (popupOkBtn) {
    popupOkBtn.addEventListener('click', closePopup);
}

/* ============================
   INIT
============================ */
document.addEventListener('DOMContentLoaded', () => {
    setupPasswordToggle();
    setupPasswordStrengthIndicator();
});
