function setupPasswordToggle() {
    document.querySelectorAll('.password-toggle').forEach(button => {
        button.addEventListener('click', () => {
            const wrapper = button.closest('.relative');
            if (!wrapper) return;

            const input = wrapper.querySelector('.password-input');
            const eyeOpen = button.querySelector('.eye-icon-open');
            const eyeClosed = button.querySelector('.eye-icon-closed');

            if (input.type === 'password') {
                input.type = 'text';
                eyeOpen.classList.remove('hidden');
                eyeClosed.classList.add('hidden');
            } else {
                input.type = 'password';
                eyeOpen.classList.add('hidden');
                eyeClosed.classList.remove('hidden');
            }
        });
    });
}

// ================= POPUP =================
function showPopup(message) {
    document.getElementById('popupMessage').textContent = message;
    document.getElementById('popupOverlay').classList.remove('hidden');
}

function closePopup() {
    document.getElementById('popupOverlay').classList.add('hidden');
}

// ================= VALIDATION =================
function validateForm(name, email, password, confirm) {
    if (name.length < 3) return 'Nama minimal 3 karakter';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return 'Email tidak valid';
    if (password.length < 8) return 'Password minimal 8 karakter';
    if (password !== confirm) return 'Password dan konfirmasi tidak sama';
    return null;
}

// ================= PASSWORD STRENGTH =================
const strengthBar = document.getElementById('passwordStrengthBar');
const strengthText = document.getElementById('passwordStrengthText');

function checkPasswordStrength(password) {
    let strength = 0;

    if (password.length >= 8) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    if (strength <= 1) {
        strengthBar.style.width = '33%';
        strengthBar.style.background = '#b45309'; // tobacco
        strengthText.textContent = 'Weak password';
        strengthText.style.color = '#b45309';
    } else if (strength === 2 || strength === 3) {
        strengthBar.style.width = '66%';
        strengthBar.style.background = '#92400e';
        strengthText.textContent = 'Medium password';
        strengthText.style.color = '#92400e';
    } else {
        strengthBar.style.width = '100%';
        strengthBar.style.background = '#15803d';
        strengthText.textContent = 'Strong password';
        strengthText.style.color = '#15803d';
    }
}

// ================= INPUT FOCUS COLOR =================
document.querySelectorAll('input').forEach(input => {
    input.addEventListener('focus', () => {
        input.style.borderColor = 'var(--color-tobacco)';
    });

    input.addEventListener('blur', () => {
        input.style.borderColor = 'var(--color-mahogany)';
    });
});

// ================= SUBMIT (FIREBASE AUTH) =================
document.addEventListener('DOMContentLoaded', () => {
    setupPasswordToggle();

    regPassword.addEventListener('input', e => {
        checkPasswordStrength(e.target.value);
    });

    document.getElementById('registerForm').addEventListener('submit', async e => {
        e.preventDefault();

        const name = regName.value.trim();
        const email = regEmail.value.trim().toLowerCase();
        const password = regPassword.value;
        const confirm = regConfirmPassword.value;

        const error = validateForm(name, email, password, confirm);
        if (error) {
            showPopup(`❌ ${error}`);
            return;
        }

        signUpBtn.disabled = true;
        signUpBtn.textContent = 'Mendaftarkan...';

        try {
            // 🔥 FIREBASE REGISTER
            const userCredential = await firebase
                .auth()
                .createUserWithEmailAndPassword(email, password);

            await userCredential.user.updateProfile({
                displayName: name
            });

            showPopup('✅ Akun berhasil dibuat!');
            setTimeout(() => location.href = 'login.html', 1500);

        } catch (err) {
            let message = 'Terjadi kesalahan. Silakan coba lagi.';

            if (err.code === 'auth/email-already-in-use') {
                message = '❌ The email address is already in use by another account.';
            } else if (err.code === 'auth/invalid-email') {
                message = '❌ Email tidak valid.';
            } else if (err.code === 'auth/weak-password') {
                message = '❌ Password terlalu lemah.';
            }

            showPopup(message);
        }
    });
});
