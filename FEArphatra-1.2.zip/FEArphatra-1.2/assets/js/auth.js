import { API_BASE_URL, firebaseConfig } from './config.js';
import { log } from './ui.js';

// ================= CONFIG =================
export const TOKEN_KEY = 'token';

// ================= FIREBASE INIT =================
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

// ================= TOKEN =================
function saveToken(token) {
    localStorage.setItem(TOKEN_KEY, token);
}

function getToken() {
    return localStorage.getItem(TOKEN_KEY);
}

function clearToken() {
    localStorage.removeItem(TOKEN_KEY);
}

// ================= USER STATUS =================
function saveUserData(userData) {
    localStorage.setItem('arphatra_user', JSON.stringify(userData));
}

function getUserData() {
    const userData = localStorage.getItem('arphatra_user');
    return userData ? JSON.parse(userData) : null;
}

function setIsNewUser(isNew) {
    localStorage.setItem('arphatra_isNewUser', isNew ? 'true' : 'false');
}

function getIsNewUser() {
    return localStorage.getItem('arphatra_isNewUser') === 'true';
}

function clearUserData() {
    localStorage.removeItem('arphatra_user');
    localStorage.removeItem('arphatra_isNewUser');
}

// ================= PASSWORD TOGGLE =================
function setupPasswordToggle() {
    const toggleButtons = document.querySelectorAll('.password-toggle');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Try to find input field - multiple ways to locate it
            let input = null;
            
            // Method 1: Look for .password-input class
            input = button.closest('.password-input-wrapper')?.querySelector('.password-input') || 
                   button.closest('.flex')?.querySelector('.password-input');
            
            // Method 2: Look for input with type=password/text in same parent
            if (!input) {
                const parent = button.closest('div');
                input = parent?.querySelector('input[type="password"], input[type="text"]');
            }
            
            if (input) {
                // Handle SVG inline (from login/register)
                const eyeOpen = button.querySelector('.eye-icon-open');
                const eyeClosed = button.querySelector('.eye-icon-closed');
                
                if (eyeOpen && eyeClosed) {
                    if (input.type === 'password') {
                        input.type = 'text';
                        eyeOpen.style.display = 'none';
                        eyeClosed.style.display = 'block';
                    } else {
                        input.type = 'password';
                        eyeOpen.style.display = 'block';
                        eyeClosed.style.display = 'none';
                    }
                }
                
                // Handle IMG tag (from resetpass.html)
                const img = button.querySelector('img');
                if (img) {
                    if (input.type === 'password') {
                        input.type = 'text';
                        img.src = '../assets/icons/login/eye-open.svg';
                    } else {
                        input.type = 'password';
                        img.src = '../assets/icons/login/eye-closed.svg';
                    }
                }
            }
        });
    });
}

// Initialize password toggle on page load
document.addEventListener('DOMContentLoaded', setupPasswordToggle);



// ================= LOGIN EMAIL =================
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const loginEmail = document.getElementById('loginEmail');
    const loginPassword = document.getElementById('loginPassword');

    try {
        log('Login via cloud...');
        const res = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: loginEmail.value.trim(),
                password: loginPassword.value
            })
        });

        const data = await res.json();

        // ================= STRICT FRONTEND VALIDATION =================
        const isHttpOk = res.ok;
        const hasSuccessFlag = data.success === true;
        const hasToken = !!data.data?.idToken;
        const message = (data.message || '').toLowerCase();

        const containsErrorKeyword =
            message.includes('password') ||
            message.includes('wrong') ||
            message.includes('invalid') ||
            message.includes('not found') ||
            message.includes('register');

        console.log('🔐 Login Validation Check:', {
            isHttpOk,
            hasSuccessFlag,
            hasToken,
            containsErrorKeyword,
            message
        });

        if (
            isHttpOk &&
            hasSuccessFlag &&
            hasToken &&
            !containsErrorKeyword
        ) {
            // ✅ LOGIN VALID
            saveToken(data.data.idToken);

            saveUserData({
                fullName: data.data?.fullName || loginEmail.value,
                email: loginEmail.value,
                id: data.data?.userId || loginEmail.value.split('@')[0]
            });

            setIsNewUser(false);

            log('Login berhasil!', false);
            setTimeout(() => window.location.href = 'homepage.html', 1000);
        } else {
            // ❌ LOGIN DITOLAK OLEH FRONTEND
            clearToken();
            clearUserData();
            setIsNewUser(false);

            let errorMessage = 'Incorrect email or password.';
            if (message.includes('register') || message.includes('not found')) {
                errorMessage = 'Your account is not registered. Please register first.';
            }

            log(errorMessage, true);
            return false;
        }
    } catch (error) {
        console.error('❌ Login Error:', error);
        clearToken();
        clearUserData();
        setIsNewUser(false);
        log('Login failed. Please try again.', true);
        return false;
    }
});

// ================= GOOGLE LOGIN =================
window.loginWithGoogle = async function () {
    try {
        log('Login Google...');
        const provider = new firebase.auth.GoogleAuthProvider();
        provider.setCustomParameters({
            prompt: 'select_account'
        });
        
        const result = await firebase.auth().signInWithPopup(provider);
        const idToken = await result.user.getIdToken();
        const googleUser = result.user;

        const res = await fetch(`${API_BASE_URL}/google`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ idToken })
        });

        const data = await res.json();
        
        // DEBUG LOG
        console.log('📋 Google Login Response:', {
            status: res.status,
            success: data.success,
            message: data.message,
            hasUserId: !!data.data?.userId,
            responseData: data
        });

        // STRICT VALIDATION - Hanya success true yang bisa login
        if (data.success === true) {
            // ✅ LOGIN BERHASIL - Akun Google terdaftar
            console.log('✅ Google login validation PASSED');
            
            saveToken(idToken);
            
            // Check if this is first login after registration (from backend)
            const isNewUserFromBackend = data.data?.isNewUser || false;
            
            // Save user data
            saveUserData({
                fullName: googleUser.displayName || 'User',
                email: googleUser.email,
                id: data.data?.userId || null
            });
            
            // Set flag based on backend response
            // isNewUser = true berarti user baru saja register dengan akun Google
            setIsNewUser(isNewUserFromBackend);
            
            console.log(`👤 Google User Status - New: ${isNewUserFromBackend}`);
            
            log('Google login berhasil!', false);
            setTimeout(() => window.location.href = 'homepage.html', 1000);
        } else {
            // ❌ LOGIN GAGAL - Akun Google tidak terdaftar
            console.log('❌ Google login validation FAILED');
            console.log('Alasan:', {
                successIsFalse: data.success === false,
                message: data.message
            });
            
            const errorMessage = data.message || 'Your Account was not found, please register first.';
            log(errorMessage, true);
            
            // Clear Firebase session
            await firebase.auth().signOut();
            
            // 🛡️ Clear any saved tokens - PENTING!
            clearToken();
            clearUserData();
            setIsNewUser(false);
            
            return false;
        }
    } catch (error) {
        if (error.code === 'auth/popup-closed-by-user') {
            log('Google login dibatalkan', true);
            return;
        }
        console.error('❌ Google Login Error:', error);
        log('Google login gagal: ' + error.message, true);
        clearToken();
        clearUserData();
        setIsNewUser(false);
        return false;
    }
};

// ================= PROFILE =================
async function fetchProfile() {
    const token = getToken();
    if (!token) return;

    try {
        const res = await fetch(`${API_BASE_URL}/profile`, {
            headers: { Authorization: `Bearer ${token}` }
        });

        const data = await res.json();
        if (data.success) {
            const userData = document.getElementById('userData');
            if (userData) {
                userData.innerHTML = `<pre>${JSON.stringify(data.data, null, 2)}</pre>`;
            }
        } else {
            logout();
        }
    } catch (error) {
        log('Session invalid: ' + error.message, true);
    }
}

function showLoggedInUI() {
    const profileSection = document.getElementById('profileSection');
    const loginSection = document.getElementById('loginSection');
    
    if (profileSection) profileSection.classList.remove('hidden');
    if (loginSection) loginSection.classList.add('hidden');
    fetchProfile();
}

// ================= LOGOUT =================
window.logout = async function () {
    try {
        await fetch(`${API_BASE_URL}/logout`, { method: 'POST' });
    } catch {}

    clearToken();
    clearUserData();
    
    const profileSection = document.getElementById('profileSection');
    const loginSection = document.getElementById('loginSection');
    
    if (profileSection) profileSection.classList.add('hidden');
    if (loginSection) loginSection.classList.remove('hidden');
    log('Logout berhasil', false);
    
    setTimeout(() => location.reload(), 1000);
};

// ================= AUTO LOGIN =================
if (getToken()) {
    showLoggedInUI();
}
