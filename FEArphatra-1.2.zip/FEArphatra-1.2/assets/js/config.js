/**
 * Configuration Module
 * Berisi semua konfigurasi global
 * - API endpoints
 * - Firebase config
 * - Konstanta aplikasi
 */

// ============================================
// BACKEND API CONFIGURATION
// ============================================

/**
 * Base URL untuk semua API request
 * Pastikan sesuai dengan backend deployment
 */
export const API_BASE_URL = "https://expressapi-m6mrpekhiq-uc.a.run.app";

// ============================================
// FIREBASE CONFIGURATION
// ============================================

/**
 * Firebase config (AMAN di frontend)
 * 📌 API key Firebase BUKAN secret, hanya penanda project
 * Keamanan ada di Firebase Rules, bukan di API key
 */
export const firebaseConfig = {
  apiKey: "AIzaSyBzzx9itbJRQl6Q1DVHnVZzt_aZntBF0i4",
  authDomain: "pentataste-ff444.firebaseapp.com",
  projectId: "pentataste-ff444",
  storageBucket: "pentataste-ff444.appspot.com",
  messagingSenderId: "834945852866",
  appId: "1:834945852866:web:d6e0c7f6b8a9e1c2f3b4a5c6",
};

// ============================================
// CONSTANTS
// ============================================

/**
 * Waktu timeout untuk fetch request (ms)
 */
export const FETCH_TIMEOUT = 15000; // 15 detik

/**
 * Key untuk localStorage
 */
export const TOKEN_KEY = "auth_token";
export const USER_KEY = "user_data";

/**
 * Validasi password minimum
 */
export const PASSWORD_MIN_LENGTH = 8;

/**
 * Status code yang menandakan token invalid
 */
export const UNAUTHORIZED_STATUS = 401;
