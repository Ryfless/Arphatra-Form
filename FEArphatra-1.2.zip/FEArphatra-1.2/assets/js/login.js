import { API_BASE_URL } from "./config.js";

document.addEventListener("DOMContentLoaded", () => {

    /* ================= PASSWORD TOGGLE ================= */
    document.querySelectorAll(".password-toggle").forEach(button => {
        button.addEventListener("click", () => {
            const inputId = button.getAttribute("data-target");
            const passwordInput = document.getElementById(inputId);
            const icon = button.querySelector("img");

            if (!passwordInput || !icon) return;

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                icon.src = "../assets/icons/login/eye-open.svg";
            } else {
                passwordInput.type = "password";
                icon.src = "../assets/icons/login/eye-closed.svg";
            }
        });
    });

    /* ================= LOGIN ================= */
    const loginForm = document.getElementById("loginForm");

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const email = document.getElementById("loginEmail").value.trim();
        const password = document.getElementById("loginPassword").value.trim();

        if (!isValidEmail(email)) {
            showPopup("Email format is incorrect", "error");
            return;
        }

        if (!password) {
            showPopup("Passwords do not match", "error");
            return;
        }

        try {
            const res = await fetch(`${API_BASE_URL}/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password })
            });

            const data = await res.json();

            if (data.success && data.data?.idToken) {
                showPopup("Login successful", "success");

                setTimeout(() => {
                    window.location.href = "homepage.html";
                }, 1200);
                return;
            }

            showPopup(
                data.message || "Account is not registered, please register first",
                "error"
            );

        } catch (err) {
            console.error(err);
            showPopup("Account is not registered, please register first", "error");
        }
    });

});

/* ================= POPUP ================= */
function showPopup(message, type = "info") {
    const overlay = document.getElementById("popupOverlay");
    const box = overlay.querySelector(".popup-box");
    const msg = document.getElementById("popupMessage");
    const okBtn = document.getElementById("popupOkBtn");

    msg.textContent = message;

    box.classList.remove("popup-success", "popup-error");

    if (type === "success") {
        box.classList.add("popup-success");
        okBtn.style.display = "none";
    } else {
        box.classList.add("popup-error");
        okBtn.style.display = "inline-block";
    }

    overlay.classList.remove("hidden");
}

window.closePopup = function () {
    document.getElementById("popupOverlay").classList.add("hidden");
};

/* ================= EMAIL VALIDATION ================= */
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/* ================= GOOGLE LOGIN ================= */
window.handleGoogleLogin = async function () {
    try {
        await window.loginWithGoogle();
    } catch {
        showPopup("Account is not registered, please register first", "error");
    }
};
