// ================= UI HELPERS =================

export function log(message, isError = false) {
    const div = document.getElementById('consoleLog');
    if (!div) return;

    const p = document.createElement('p');
    p.className = isError ? 'text-red-400' : 'text-green-400';
    p.textContent = `> [${new Date().toLocaleTimeString()}] ${message}`;

    div.appendChild(p);
    div.scrollTop = div.scrollHeight;
}

export function toggleForgot(show) {
    const loginSection = document.getElementById('loginSection');
    const forgotSection = document.getElementById('forgotSection');
    
    if (loginSection) {
        loginSection.classList.toggle('hidden', show);
    }
    if (forgotSection) {
        forgotSection.classList.toggle('hidden', !show);
    }

    if (!show) {
        const otpStep = document.getElementById('otpStep');
        const resetStep = document.getElementById('resetStep');
        
        if (otpStep) otpStep.classList.remove('hidden');
        if (resetStep) resetStep.classList.add('hidden');
    }
}
