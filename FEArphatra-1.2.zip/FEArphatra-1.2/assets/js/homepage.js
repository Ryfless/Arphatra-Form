// ============================================
// DUMMY FORMS DATA - BERBAGAI SKENARIO
// ============================================
import { API_BASE_URL, firebaseConfig } from './config.js';
import { log } from './ui.js'
// SKENARIO 1: User Baru (Belum punya form)
const formsDataNewUser = {};

// SKENARIO 2: User Normal (Punya form history - Default)
const formsDataNormalUser = {
    today: [
        { id: 1, title: 'Customer Survey Form', time: '12:06' },
        { id: 2, title: 'Monthly Report', time: '13:06', highlighted: true },
        { id: 3, title: 'Employee Feedback', time: '14:14' },
        { id: 4, title: 'Event Registration', time: '15:05' },
        { id: 5, title: 'Product Feedback', time: '16:20' },
        { id: 6, title: 'Support Ticket Form', time: '17:02' },
        { id: 7, title: 'Contact Us Form', time: '18:00' },
        { id: 8, title: 'Newsletter Signup', time: '19:30' }
    ],
    thisweek: [
        { id: 9, title: 'Customer Survey', time: 'Mon 10:30' },
        { id: 10, title: 'Employee Feedback', time: 'Tue 14:45' },
        { id: 11, title: 'Product Review', time: 'Wed 16:20' },
        { id: 12, title: 'Weekly Report', time: 'Thu 09:15' }
    ],
    thismonth: [
        { id: 13, title: 'Event Registration', time: '5 Jan' },
        { id: 14, title: 'Feedback Form', time: '8 Jan' },
        { id: 15, title: 'Sales Inquiry', time: '12 Jan' }
    ],
    other: [
        { id: 16, title: 'Old Survey 2024', time: 'Dec 2024' },
        { id: 17, title: 'Archive Form', time: 'Nov 2024' }
    ]
};

// SKENARIO 3: User dengan banyak form setiap periode
const formsDataActiveUser = {
    today: [
        { id: 1, title: 'Daily Standup', time: '08:00' },
        { id: 2, title: 'Customer Support', time: '09:15', highlighted: true },
        { id: 3, title: 'Team Meeting Notes', time: '10:30' },
        { id: 4, title: 'Bug Report Form', time: '11:45' },
        { id: 5, title: 'Feature Request', time: '13:00' },
        { id: 6, title: 'Performance Metrics', time: '14:15' },
        { id: 7, title: 'End of Day Report', time: '17:00' },
        { id: 8, title: 'Time Tracking', time: '17:30' }
    ],
    thisweek: [
        { id: 9, title: 'Daily Standup', time: 'Mon 08:00' },
        { id: 10, title: 'Customer Support', time: 'Tue 09:15' },
        { id: 11, title: 'Team Meeting', time: 'Wed 10:30' },
        { id: 12, title: 'Bug Report', time: 'Thu 11:45' },
        { id: 13, title: 'Feature Request', time: 'Fri 13:00' },
        { id: 14, title: 'Performance Review', time: 'Fri 14:15' }
    ],
    thismonth: [
        { id: 15, title: 'Daily Standup', time: '7 Jan' },
        { id: 16, title: 'Customer Support', time: '10 Jan' },
        { id: 17, title: 'Team Meeting', time: '15 Jan' },
        { id: 18, title: 'Bug Report', time: '20 Jan' }
    ],
    other: [
        { id: 19, title: 'Old Projects 2024', time: 'Dec 2024' },
        { id: 20, title: 'Archive', time: 'Nov 2024' }
    ]
};

// SKENARIO 4: User dengan form hanya di Today
const formsDataOnlyToday = {
    today: [
        { id: 1, title: 'Project Proposal', time: '10:00' },
        { id: 2, title: 'Client Feedback', time: '14:30', highlighted: true }
    ],
    thisweek: [],
    thismonth: [],
    other: []
};

// SKENARIO 5: User dengan form di berbagai periode
const formsDataMixedPeriods = {
    today: [],
    thisweek: [
        { id: 1, title: 'Team Retrospective', time: 'Mon 10:00' },
        { id: 2, title: 'Sprint Planning', time: 'Wed 14:00' }
    ],
    thismonth: [
        { id: 3, title: 'Project Kickoff', time: '5 Jan 09:00' },
        { id: 4, title: 'Design Review', time: '12 Jan 15:00' }
    ],
    other: [
        { id: 5, title: 'Old Form 2024', time: 'Dec 2024' }
    ]
};

// DEFAULT: Gunakan Normal User data
let formsData = formsDataNormalUser;

// ============================================
// AUTO-DETECT NEW USER FROM STORAGE & SHOW CORRECT LAYOUT
// ============================================
function initializeFormDataBasedOnUserStatus() {
    // Get flag dari localStorage yang di-set oleh auth.js
    const isNewUser = localStorage.getItem('arphatra_isNewUser') === 'true';
    
    if (isNewUser) {
        // User baru - gunakan form kosong
        formsData = formsDataNewUser;
        console.log('✅ Menampilkan tampilan user baru (form kosong)');
        console.log('🖼️ Show gambar: newForm-empty.png');
        
        // SWITCH TO NEW USER LAYOUT
        switchToNewUserLayout();
    } else {
        // User existing - gunakan normal user data
        formsData = formsDataNormalUser;
        console.log('✅ Menampilkan tampilan user existing (form tersedia)');
        console.log('🖼️ Show gambar: new-form.png');
        
        // SWITCH TO EXISTING USER LAYOUT
        switchToExistingUserLayout();
    }
}

// ============================================
// LAYOUT SWITCHER FUNCTIONS
// ============================================
function switchToNewUserLayout() {
    const newUserLayout = document.getElementById('new-user-layout');
    const existingUserLayout = document.getElementById('existing-user-layout');
    
    if (newUserLayout && existingUserLayout) {
        newUserLayout.classList.remove('hidden');
        existingUserLayout.classList.add('hidden');
        
        // Update user name in new user layout
        const userNewElement = document.getElementById('userName-new');
        const userExistingElement = document.getElementById('userName');
        if (userNewElement && userExistingElement) {
            userNewElement.textContent = userExistingElement.textContent;
        }
        
        console.log('🎨 Switched to NEW USER layout');
    }
}

function switchToExistingUserLayout() {
    const newUserLayout = document.getElementById('new-user-layout');
    const existingUserLayout = document.getElementById('existing-user-layout');
    
    if (newUserLayout && existingUserLayout) {
        newUserLayout.classList.add('hidden');
        existingUserLayout.classList.remove('hidden');
        console.log('🎨 Switched to EXISTING USER layout');
    }
}

// Initialize saat halaman dimuat
initializeFormDataBasedOnUserStatus();

// ============================================
// FUNCTION: Switching antar Skenario
// ============================================
function switchScenario(scenario) {
    const scenarios = {
        'new': formsDataNewUser,
        'normal': formsDataNormalUser,
        'active': formsDataActiveUser,
        'today-only': formsDataOnlyToday,
        'mixed': formsDataMixedPeriods
    };

    if (scenarios[scenario]) {
        formsData = scenarios[scenario];
        console.log(`✅ Switched to: ${scenario.toUpperCase()} scenario`);
        console.log('Data:', formsData);
        // Re-render UI
        updateUIVisibility();
        renderForms('today');
        updateCreateFormImage();
    } else {
        console.error(`❌ Scenario "${scenario}" not found. Available: ${Object.keys(scenarios).join(', ')}`);
    }
}

// Shortcut functions untuk testing (bisa dijalankan di browser console)
window.testNewUser = () => switchScenario('new');
window.testNormalUser = () => switchScenario('normal');
window.testActiveUser = () => switchScenario('active');
window.testOnlyToday = () => switchScenario('today-only');
window.testMixedPeriods = () => switchScenario('mixed');

// Helper function: Check if user has any forms
function hasUserForms() {
    return Object.values(formsData).some(dayForms => Array.isArray(dayForms) && dayForms.length > 0);
}

// Helper function: Update create form image for new user
function updateCreateFormImage() {
    // Check user status dari localStorage flag
    const isNewUser = localStorage.getItem('arphatra_isNewUser') === 'true';
    const createFormImage = document.getElementById('create-form-image');
    const createFormCard = document.getElementById('create-form-card');
    
    if (createFormImage && createFormCard) {
        if (isNewUser) {
            // NEW USER: Show newForm-empty gambar
            createFormImage.src = '../assets/images/newForm-empty.png';
            createFormImage.alt = 'New Form Empty';
            
            // Full width styling
            createFormCard.style.width = '100%';
            createFormCard.style.height = 'auto';
            createFormCard.style.minHeight = '500px';
            createFormCard.style.display = 'flex';
            createFormCard.style.alignItems = 'center';
            createFormCard.style.justifyContent = 'center';
            createFormCard.style.borderRadius = '0';
            createFormCard.style.boxShadow = 'none';
            
            createFormImage.className = 'w-full h-auto object-contain';
            createFormImage.style.boxShadow = 'none';
            createFormImage.style.borderRadius = '0';
            
            console.log('🖼️ NEW USER: Showing newForm-empty.png');
        } else {
            // EXISTING USER: Show normal new-form gambar
            createFormImage.src = '../assets/images/new-form.png';
            createFormImage.alt = 'Create New Form';
            
            // Original styling
            createFormCard.style.width = '360px';
            createFormCard.style.height = '440px';
            createFormCard.style.minHeight = 'unset';
            createFormCard.style.display = 'block';
            createFormCard.style.borderRadius = '16px';
            createFormCard.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.15)';
            
            createFormImage.className = 'w-full h-full object-cover';
            createFormImage.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.15)';
            createFormImage.style.borderRadius = '16px';
            
            console.log('🖼️ EXISTING USER: Showing new-form.png');
        }
    } else {
        console.warn('⚠️ createFormImage or createFormCard not found');
    }
}

// Helper function: Show/hide UI elements based on form availability
function updateUIVisibility() {
    const hasData = hasUserForms();
    const tabsContainer = document.getElementById('tabs-container');
    const historySection = document.getElementById('history-section');
    const emptyStateContainer = document.getElementById('empty-state-container');
    const recentFormsWrapper = document.getElementById('recent-forms-wrapper');
    const cardSection = document.getElementById('cards-section');

    if (hasData) {
        // Show tabs and history, hide empty state
        if (tabsContainer) tabsContainer.style.display = 'flex';
        if (historySection) historySection.style.display = 'flex';
        if (emptyStateContainer) emptyStateContainer.style.display = 'none';
        if (recentFormsWrapper) recentFormsWrapper.style.display = 'flex';
    } else {
        // Hide tabs and history, show empty state
        if (tabsContainer) tabsContainer.style.display = 'none';
        if (historySection) historySection.style.display = 'none';
        if (emptyStateContainer) emptyStateContainer.style.display = 'flex';
        // Keep create new form card but hide recent forms section
        if (recentFormsWrapper) recentFormsWrapper.style.display = 'none';
    }
}

// Render Table
let selectedRowId = null; // Track selected row

function renderForms(tab = 'today') {
    const tableBody = document.getElementById('table-body');
    tableBody.innerHTML = '';

    const forms = formsData[tab] || [];

    if (forms.length === 0) {
        // Show empty state for this tab
        const emptyRow = document.createElement('div');
        emptyRow.className = 'flex items-center justify-center h-full text-center';
        emptyRow.innerHTML = `
            <div style="color: var(--text-fade); padding: 2rem;">
                <p class="text-sm">No forms in this period</p>
            </div>
        `;
        tableBody.appendChild(emptyRow);
        return;
    }

    forms.forEach(form => {
        const row = document.createElement('div');
        const borderClass = form.highlighted ? '' : 'border border-gray-100';
        row.className = `grid grid-cols-[1fr_1fr_50px] gap-3 p-4 bg-[var(--color-vanilla)] rounded align-center transition-all cursor-pointer ${borderClass} shadow-md hover:bg-yellow-50`;
        row.dataset.formId = form.id;
        
        const titleColor = form.highlighted ? 'var(--color-tobacco)' : '#333';
        
        row.innerHTML = `
            <div class="flex items-center gap-2" style="color: var(--text-default); font-weight: 500; height: 100%;">
                <div class="w-8 h-8 bg-[var(--color-vanilla)] rounded flex items-center justify-center flex-shrink-0 border border-gray-300">
                    <img src="../assets/icons/homepage/doc-icon.svg" alt="Form" class="w-4 h-4 opacity-80">
                </div>
                <span class="row-title-text text-sm" style="color: ${titleColor};">${form.title}</span>
            </div>
            <div class="row-time text-sm text-left flex items-center justify-start pl-8" style="color: #a89a8a;">${form.time}</div>
            <div class="row-action flex justify-center cursor-pointer relative" style="position: relative; width: 50px; height: 100%; display: flex; align-items: center; justify-content: center;">
                <img src="../assets/icons/homepage/more-vertical.svg" alt="More" class="w-5 h-5 transition-opacity icon-more" style="position: relative; opacity: 1; z-index: 1;">
                <img src="../assets/icons/homepage/more-vertical-hover.svg" alt="More Hover" class="w-5 h-5 transition-opacity icon-more-hover" style="position: absolute; opacity: 0; z-index: 2;">
            </div>
        `;

        tableBody.appendChild(row);

        // Add hover effect for mahogany color and icons
        row.addEventListener('mouseenter', () => {
            if (selectedRowId !== form.id) {
                row.style.background = 'var(--color-mahogany)';
                row.querySelectorAll('.row-title-text, .row-time').forEach(el => {
                    el.style.color = 'white';
                    el.style.fontWeight = '600';
                });
            }
            row.querySelector('.icon-more').style.opacity = '0';
            row.querySelector('.icon-more-hover').style.opacity = '1';
        });

        row.addEventListener('mouseleave', () => {
            if (selectedRowId !== form.id) {
                if (!form.highlighted) {
                    row.style.background = 'var(--color-vanilla)';
                    row.querySelectorAll('.row-title-text, .row-time').forEach(el => {
                        el.style.color = el.classList.contains('row-title-text') ? '#333' : '#a89a8a';
                        el.style.fontWeight = '500';
                    });
                } else {
                    row.style.background = 'var(--color-vanilla)';
                    row.querySelector('.row-title-text').style.color = 'var(--color-mahogany)';
                    row.querySelector('.row-time').style.color = '#a89a8a';
                    row.querySelectorAll('.row-title-text, .row-time').forEach(el => {
                        el.style.fontWeight = '500';
                    });
                }
                row.querySelector('.icon-more').style.opacity = '1';
                row.querySelector('.icon-more-hover').style.opacity = '0';
            } else {
                // If this is the selected row, keep hover icon
                row.querySelector('.icon-more').style.opacity = '0';
                row.querySelector('.icon-more-hover').style.opacity = '1';
            }
        });

        // Add click event for more options
        row.querySelector('.row-action')?.addEventListener('click', (e) => {
            e.stopPropagation();
            console.log('More options for:', form.title);
        });

        // Add click event for row selection
        row.addEventListener('click', () => {
            // Remove selection from previous row
            if (selectedRowId !== null) {
                const previousRow = tableBody.querySelector(`[data-form-id="${selectedRowId}"]`);
                if (previousRow) {
                    const previousForm = forms.find(f => f.id === parseInt(selectedRowId));
                    if (!previousForm?.highlighted) {
                        previousRow.style.background = 'var(--color-vanilla)';
                        previousRow.querySelectorAll('.row-title-text, .row-time').forEach(el => {
                            el.style.color = el.classList.contains('row-title-text') ? '#333' : '#a89a8a';
                            el.style.fontWeight = '500';
                        });
                    } else {
                        previousRow.style.background = 'var(--color-vanilla)';
                        previousRow.querySelector('.row-title-text').style.color = 'var(--color-mahogany)';
                        previousRow.querySelector('.row-time').style.color = '#a89a8a';
                    }
                    previousRow.querySelector('.icon-more').style.opacity = '1';
                    previousRow.querySelector('.icon-more-hover').style.opacity = '0';
                }
            }

            // Select current row
            selectedRowId = form.id;
            row.style.background = 'var(--color-mahogany)';
            row.querySelectorAll('.row-title-text, .row-time').forEach(el => {
                el.style.color = 'white';
                el.style.fontWeight = '600';
            });
            row.querySelector('.icon-more').style.opacity = '0';
            row.querySelector('.icon-more-hover').style.opacity = '1';

            console.log('Selected form:', form.title);
        });

        // Highlighted styling (for "Old 2" row)
        if (form.highlighted) {
            row.style.background = 'var(--color-mahogany)';
            row.style.borderColor = 'var(--color-mahogany)';
            row.querySelectorAll('.row-title-text, .row-time').forEach(el => {
                el.style.color = 'var(--color-rice)';
                el.style.fontWeight = '600';
            });
            row.querySelector('.icon-more').style.opacity = '0';
            row.querySelector('.icon-more-hover').style.opacity = '1';
            selectedRowId = form.id; // Set as selected by default
        }
    });
}

// Tab Switching
function setupTabs() {
    const tabButtons = document.querySelectorAll('[data-tab]');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active styling from all buttons
            tabButtons.forEach(b => {
                b.style.color = 'var(--text-fade)';
                b.style.borderBottom = '3px solid transparent';
                b.classList.remove('active');
            });
            
            // Add active styling to clicked button
            btn.style.color = 'var(--text-default)';
            btn.style.borderBottom = '3px solid var(--text-default)';
            btn.classList.add('active');

            // Render forms for selected tab
            const tab = btn.dataset.tab;
            renderForms(tab);
        });
    });
}

// Create New Form Card Click
function setupCreateCard() {
    const createCard = document.querySelector('.create-card');
    
    if (createCard) {
        createCard.addEventListener('click', () => {
            console.log('Navigate to create new form');
            // window.location.href = 'create-form.html';
        });
    }
}

// Recent Form Card Click
function setupRecentCard() {
    const recentCard = document.querySelector('.recent-card');
    
    if (recentCard) {
        recentCard.addEventListener('click', () => {
            console.log('Navigate to recent form');
            // window.location.href = 'form-details.html';
        });
    }
}

// More Vertical Icon Hover
function setupMoreVerticalHover() {
    const tableBody = document.getElementById('table-body');
    
    if (tableBody) {
        tableBody.addEventListener('mouseenter', (e) => {
            if (e.target.closest('.table-row')) {
                const row = e.target.closest('.table-row');
                const img = row.querySelector('.row-action img');
                if (img && img.src.includes('more-vertical.svg') && !img.src.includes('hover')) {
                    img.src = '../assets/icons/homepage/more-vertical-hover.svg';
                }
            }
        }, true);

        tableBody.addEventListener('mouseleave', (e) => {
            if (e.target.closest('.table-row')) {
                const row = e.target.closest('.table-row');
                const img = row.querySelector('.row-action img');
                if (img && img.src.includes('more-vertical-hover.svg')) {
                    img.src = '../assets/icons/homepage/more-vertical.svg';
                }
            }
        }, true);
    }
}

// Search functionality
function setupSearch() {
    const searchInput = document.querySelector('.search-bar input');
    
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            console.log('Searching for:', query);
            
            const rows = document.querySelectorAll('.table-row');
            rows.forEach(row => {
                const title = row.querySelector('.row-title-text').textContent.toLowerCase();
                if (title.includes(query)) {
                    row.style.display = 'grid';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
}

// Setup Form Cards
function setupFormCards() {
    const formWrappers = document.querySelectorAll('[class*="relative cursor-pointer transition-all hover:translate-y"]');
    
    formWrappers.forEach(wrapper => {
        wrapper.addEventListener('mouseenter', () => {
            const moreHover = wrapper.querySelector('[alt="More Hover"]');
            const more = wrapper.querySelector('[alt="More"]');
            if (moreHover && more) {
                moreHover.style.opacity = '1';
                more.style.opacity = '0';
            }
        });
        
        wrapper.addEventListener('mouseleave', () => {
            const moreHover = wrapper.querySelector('[alt="More Hover"]');
            const more = wrapper.querySelector('[alt="More"]');
            if (moreHover && more) {
                moreHover.style.opacity = '0';
                more.style.opacity = '1';
            }
        });
    });
}

// Profile Icon Click
function setupProfile() {
    const profileIcon = document.querySelector('.header-right img');
    
    if (profileIcon) {
        profileIcon.addEventListener('click', () => {
            console.log('Open profile menu');
        });
    }
}

// Empty State Button Click
function setupEmptyStateButton() {
    const emptyStateBtn = document.querySelector('#empty-state-container button');
    
    if (emptyStateBtn) {
        emptyStateBtn.addEventListener('click', () => {
            console.log('Redirect to create new form page');
            // Uncomment line di bawah untuk production
            // window.location.href = './create-form.html';
        });
    }
}

// ================= PASSWORD TOGGLE =================
function setupPasswordToggle() {
    const toggleButtons = document.querySelectorAll('.password-toggle');
    
    toggleButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            
            const input = button.closest('div').querySelector('.password-input');
            const eyeOpen = button.querySelector('.eye-icon-open');
            const eyeClosed = button.querySelector('.eye-icon-closed');
            
            if (input.type === 'password') {
                input.type = 'text';
                eyeOpen.style.display = 'none';
                eyeClosed.style.display = 'block';
            } else {
                input.type = 'password';
                eyeOpen.style.display = 'block';
                eyeClosed.style.display = 'none';
            }
        });
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    // Check if new user or existing user
    const isNewUser = localStorage.getItem('arphatra_isNewUser') === 'true';
    
    if (isNewUser) {
        // NEW USER: Only show new user layout
        console.log('📍 Initializing NEW USER layout...');
        switchToNewUserLayout();
        setupPasswordToggle(); // Setup password toggle untuk new user layout
        console.log('✅ New user layout ready');
    } else {
        // EXISTING USER: Show existing user layout with data
        console.log('📍 Initializing EXISTING USER layout...');
        switchToExistingUserLayout();
        updateUIVisibility(); // Check if user has forms first
        renderForms('today');
        setupTabs();
        setupCreateCard();
        setupRecentCard();
        setupFormCards();
        setupMoreVerticalHover();
        setupSearch();
        setupProfile();
        setupPasswordToggle(); // Setup password toggle untuk existing user layout
        console.log('✅ Existing user layout ready');
    }
    
    setupProfile();
});
