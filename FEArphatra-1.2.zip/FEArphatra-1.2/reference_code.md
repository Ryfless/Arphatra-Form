# Recode Frontend Auth Firebase + Cloud API

Dokumen ini berisi **SELURUH kode JavaScript** yang diimplementasikan, disimpan dalam **format Markdown** agar:
- Mudah dipelajari ulang
- Bisa dijadikan README / dokumentasi project
- Aman dibagikan ke tim atau dosen

---

## 1. Struktur Folder Final

```text
/assets
 ├── js/
 │    ├── config.js       → Konfigurasi global (API_BASE_URL, Firebase)
 │    ├── ui.js           → Helper UI & logging
 │    └── auth.js         → Logic autentikasi lengkap
 ├── css/
 │    └── (styling files)
 └── icons/ & images/

/pages
 ├── login.html          → Login page
 ├── register.html       → Register page
 ├── resetpass.html      → Forgot password & reset page
 ├── otp.html            → OTP verification page
 ├── homepage.html       → Main app page (protected)
 └── debug.html
```

---

## 2. `config.js`

Berisi **konfigurasi global** yang dapat diakses oleh semua module.

```js
// ================= CONFIG =================

// Backend API (Cloud Function / Cloud Run)
export const API_BASE_URL = "https://expressapi-m6mrpekhiq-uc.a.run.app";

// Firebase config (AMAN di frontend)
export const firebaseConfig = {
    apiKey: "AIzaSyBzzx9itbJRQl6Q1DVHnVZzt_aZntBF0i4",
    authDomain: "pentataste-ff444.firebaseapp.com",
    projectId: "pentataste-ff444",
};

// Timeout untuk request (ms)
export const FETCH_TIMEOUT = 10000;

// LocalStorage keys
export const TOKEN_KEY = 'token';
export const USER_KEY = 'arphatra_user';

// Password validation
export const PASSWORD_MIN_LENGTH = 8;

// HTTP Status
export const UNAUTHORIZED_STATUS = 401;
```

---

## 3. `ui.js`

Berisi helper UI & logging yang simple.

```js
// ================= UI HELPERS =================

export function log(message, isError = false) {
    const div = document.getElementById('consoleLog');
    if (!div) return;

    const p = document.createElement('p');
    p.className = isError ? 'text-red-400' : 'text-green-400';
    p.textContent = `> [${new Date().toLocaleTimeString()}] ${message}`;

    div.appendChild(p);
    div.scrollTop = div.scrollHeight;
}

export function toggleForgot(show) {
    const loginSection = document.getElementById('loginSection');
    const forgotSection = document.getElementById('forgotSection');
    
    if (loginSection) {
        loginSection.classList.toggle('hidden', show);
    }
    if (forgotSection) {
        forgotSection.classList.toggle('hidden', !show);
    }

    if (!show) {
        const otpStep = document.getElementById('otpStep');
        const resetStep = document.getElementById('resetStep');
        
        if (otpStep) otpStep.classList.remove('hidden');
        if (resetStep) resetStep.classList.add('hidden');
    }
}
```

---

## 4. `auth.js` - Authentication Module

File **paling penting** (logic autentikasi lengkap).

```js
import { API_BASE_URL, firebaseConfig } from './config.js';
import { log } from './ui.js';

// ================= CONFIG =================
export const TOKEN_KEY = 'token';

// ================= FIREBASE INIT =================
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

// ================= TOKEN =================
function saveToken(token) {
    localStorage.setItem(TOKEN_KEY, token);
}

function getToken() {
    return localStorage.getItem(TOKEN_KEY);
}

function clearToken() {
    localStorage.removeItem(TOKEN_KEY);
}

// ================= REGISTER =================
document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const regName = document.getElementById('regName');
    const regEmail = document.getElementById('regEmail');
    const regPassword = document.getElementById('regPassword');

    if (regPassword.value.length < 8) {
        log('Password minimal 8 karakter', true);
        return;
    }

    try {
        log('Mendaftarkan user...');
        const res = await fetch(`${API_BASE_URL}/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                fullName: regName.value,
                email: regEmail.value,
                password: regPassword.value
            })
        });

        const data = await res.json();
        log(data.message, !data.success);
    } catch (error) {
        log('Registrasi gagal: ' + error.message, true);
    }
});

// ================= LOGIN EMAIL =================
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const loginEmail = document.getElementById('loginEmail');
    const loginPassword = document.getElementById('loginPassword');

    try {
        log('Login via cloud...');
        const res = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: loginEmail.value,
                password: loginPassword.value
            })
        });

        const data = await res.json();
        log(data.message, !data.success);

        if (data.success && data.data?.idToken) {
            saveToken(data.data.idToken);
            log('Login berhasil!', false);
            setTimeout(() => window.location.href = 'homepage.html', 1000);
        }
    } catch (error) {
        log('Login gagal: ' + error.message, true);
    }
});

// ================= GOOGLE LOGIN =================
window.loginWithGoogle = async function () {
    try {
        log('Login Google...');
        const provider = new firebase.auth.GoogleAuthProvider();
        provider.setCustomParameters({
            prompt: 'select_account'
        });
        
        const result = await firebase.auth().signInWithPopup(provider);
        const idToken = await result.user.getIdToken();

        const res = await fetch(`${API_BASE_URL}/google`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ idToken })
        });

        const data = await res.json();
        log(data.message, !data.success);

        if (data.success) {
            saveToken(idToken);
            log('Google login berhasil!', false);
            setTimeout(() => window.location.href = 'homepage.html', 1000);
        }
    } catch (error) {
        if (error.code === 'auth/popup-closed-by-user') {
            log('Google login dibatalkan', true);
            return;
        }
        log('Google login gagal: ' + error.message, true);
    }
};

// ================= FORGOT PASSWORD =================
window.sendOtp = async function () {
    const forgotEmail = document.getElementById('forgotEmail');
    const otpStep = document.getElementById('otpStep');
    const resetStep = document.getElementById('resetStep');

    try {
        log('Mengirim OTP...');
        const res = await fetch(`${API_BASE_URL}/forgot-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: forgotEmail.value })
        });

        const data = await res.json();
        log(data.message, !data.success);

        if (data.success) {
            otpStep.classList.add('hidden');
            resetStep.classList.remove('hidden');
        }
    } catch (error) {
        log('OTP gagal: ' + error.message, true);
    }
};

// ================= RESET PASSWORD =================
window.resetPass = async function () {
    const forgotEmail = document.getElementById('forgotEmail');
    const otpCode = document.getElementById('otpCode');
    const newPass = document.getElementById('newPass');

    try {
        log('Reset password...');
        const res = await fetch(`${API_BASE_URL}/reset-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: forgotEmail.value,
                otp: otpCode.value,
                newPassword: newPass.value
            })
        });

        const data = await res.json();
        log(data.message, !data.success);

        if (data.success) {
            log('Password berhasil direset!', false);
            setTimeout(() => location.reload(), 1500);
        }
    } catch (error) {
        log('Reset gagal: ' + error.message, true);
    }
};

// ================= PROFILE =================
async function fetchProfile() {
    const token = getToken();
    if (!token) return;

    try {
        const res = await fetch(`${API_BASE_URL}/profile`, {
            headers: { Authorization: `Bearer ${token}` }
        });

        const data = await res.json();
        if (data.success) {
            const userData = document.getElementById('userData');
            if (userData) {
                userData.innerHTML = `<pre>${JSON.stringify(data.data, null, 2)}</pre>`;
            }
        } else {
            logout();
        }
    } catch (error) {
        log('Session invalid: ' + error.message, true);
    }
}

function showLoggedInUI() {
    const profileSection = document.getElementById('profileSection');
    const loginSection = document.getElementById('loginSection');
    
    if (profileSection) profileSection.classList.remove('hidden');
    if (loginSection) loginSection.classList.add('hidden');
    fetchProfile();
}

// ================= LOGOUT =================
window.logout = async function () {
    try {
        await fetch(`${API_BASE_URL}/logout`, { method: 'POST' });
    } catch {}

    clearToken();
    
    const profileSection = document.getElementById('profileSection');
    const loginSection = document.getElementById('loginSection');
    
    if (profileSection) profileSection.classList.add('hidden');
    if (loginSection) loginSection.classList.remove('hidden');
    log('Logout berhasil', false);
    
    setTimeout(() => location.reload(), 1000);
};

// ================= AUTO LOGIN =================
if (getToken()) {
    showLoggedInUI();
}
```

---

## 5. Struktur HTML Page

### Login Page (`login.html`)
- Email & password input
- Google login button
- Forgot password link
- Register link

**ID Elements yang digunakan:**
- `loginForm` - Form submit
- `loginEmail` - Email input
- `loginPassword` - Password input
- `googleLoginBtn` - Google button → `onclick="window.loginWithGoogle()"`
- `forgotToggleBtn` - Forgot password toggle
- `consoleLog` - Log display

### Register Page (`register.html`)
- Full name, email, password input
- Submit button
- Login link

**ID Elements:**
- `registerForm` - Form submit
- `regName` - Full name input
- `regEmail` - Email input
- `regPassword` - Password input

### Reset Password Page (`resetpass.html`)
- Email input → `id="forgotEmail"`
- OTP Step → `id="otpStep"`
- OTP code input → `id="otpCode"`
- New password input → `id="newPass"`
- Reset Step → `id="resetStep"`
- Buttons: `sendOtpBtn`, `resetPassBtn`

### Homepage (`homepage.html`)
- Protected page (redirect to login jika tidak ada token)
- Logout button → `id="logoutBtn"`
- Display user name → `id="userName"`

---

## 6. Alur Autentikasi

```
┌─────────────────┐
│   LOGIN PAGE    │
└────────┬────────┘
         │
         ├─→ Email & Password (POST /login)
         │   └─→ Simpan token → Homepage
         │
         └─→ Google Sign-In (POST /google)
             └─→ Simpan token → Homepage

┌──────────────────┐
│   REGISTER PAGE  │
└────────┬─────────┘
         │
         └─→ Register (POST /register) → Kembali ke Login

┌──────────────────────────┐
│   FORGOT PASSWORD PAGE   │
└────────┬─────────────────┘
         │
         ├─→ Kirim Email (POST /forgot-password)
         │   └─→ Tampilkan OTP Input
         │
         └─→ Reset Password (POST /reset-password)
             └─→ Kembali ke Login

┌──────────────────┐
│   HOMEPAGE       │
└────────┬─────────┘
         │
         ├─→ Check token → redirect login jika tidak ada
         │
         └─→ GET /profile (Bearer token)
             └─→ Display user data
```

---

## 7. API Endpoints Required

| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | `/register` | `{ fullName, email, password }` | `{ success, message }` |
| POST | `/login` | `{ email, password }` | `{ success, data: { idToken } }` |
| POST | `/google` | `{ idToken }` | `{ success, data: { user } }` |
| POST | `/forgot-password` | `{ email }` | `{ success, message }` |
| POST | `/reset-password` | `{ email, otp, newPassword }` | `{ success, message }` |
| GET | `/profile` | Header: `Authorization: Bearer ${token}` | `{ success, data: { user data } }` |
| POST | `/logout` | - | `{ success, message }` |

---

## 8. Keamanan & Best Practices

✅ **Token disimpan di localStorage** (untuk demo)
✅ **Firebase API key aman di frontend**
✅ **Authorization header untuk protected endpoints**
✅ **Error handling yang comprehensive**

⚠️ **Untuk Production:**
- Gunakan **httpOnly cookies** bukan localStorage
- Aktifkan **Firebase App Check**
- Rate-limit **OTP** per email
- Validate semua input di backend
- Use **HTTPS** only

---

## 9. Testing Checklist

- [ ] Register user baru
- [ ] Login dengan email & password
- [ ] Login dengan Google
- [ ] Forgot password flow (OTP)
- [ ] Reset password
- [ ] Logout
- [ ] Homepage proteksi (cek redirect)
- [ ] Token persistence (refresh page)

---

## 10. Next Steps

1. **Update `config.js`** dengan API_BASE_URL yang benar
2. **Update Firebase config** dengan credential yang valid
3. **Test semua endpoints** dengan Postman
4. **Implementasi tambahan**:
   - Email verification
   - Two-factor authentication
   - Password strength indicator
   - Session timeout

---

> Dokumen ini mencerminkan **best practices frontend authentication** dengan Firebase + Custom API


