# Arphatra Login UI

## Overview
The Arphatra Login UI is a modern user interface designed for user authentication, featuring both login and registration forms. The UI utilizes Tailwind CSS for styling and includes smooth animations for transitioning between the login and registration pages.

## Features
- Responsive design using Tailwind CSS
- Login and registration forms
- Slide left and slide right animations for form transitions
- Password visibility toggle in the login form
- Google sign-in option

## Project Structure
```
arphatra-login-ui
├── src
│   ├── index.html          # Main HTML document
│   ├── styles              # Contains CSS files
│   │   ├── globals.css     # Global styles
│   │   └── animations.css   # CSS animations for transitions
│   ├── scripts             # Contains JavaScript files
│   │   └── main.js         # Main JavaScript functionality
│   └── assets              # Contains icons and images
│       ├── icons
│       │   └── login
│       │       ├── eye-on.svg      # Icon for password visibility
│       │       └── uim_google.svg   # Icon for Google sign-in
│       └── images
│           └── banner-login.png     # Image for the login form
├── tailwind.config.js      # Tailwind CSS configuration
├── package.json             # npm configuration file
└── README.md                # Project documentation
```

## Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd arphatra-login-ui
   ```
3. Install the dependencies:
   ```
   npm install
   ```

## Usage
To start the project, you can use a local server or open the `index.html` file directly in your browser. For development, consider using a tool like Live Server for automatic reloading.

## Contributing
Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for more details.