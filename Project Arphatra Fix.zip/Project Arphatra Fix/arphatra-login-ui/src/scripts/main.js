document.addEventListener('DOMContentLoaded', () => {
    const signInContainer = document.querySelector('.SignIn');
    const signUpContainer = document.querySelector('.SignUp');
    const signInButton = document.querySelector('.sign-in-btn');
    const signUpButton = document.querySelector('.sign-up-btn');

    signInButton.addEventListener('click', () => {
        signInContainer.classList.remove('hidden');
        signUpContainer.classList.add('hidden');
        signInContainer.classList.remove('slide-left');
        signInContainer.classList.add('slide-right');
    });

    signUpButton.addEventListener('click', () => {
        signUpContainer.classList.remove('hidden');
        signInContainer.classList.add('hidden');
        signUpContainer.classList.remove('slide-right');
        signUpContainer.classList.add('slide-left');
    });
});